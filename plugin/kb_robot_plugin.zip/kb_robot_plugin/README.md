# kb_robot_plugin
KB Robot plugin for KidBrightIDE

## Blocks

![KB Robot blocks](https://sv1.picz.in.th/images/2019/06/11/191ys8.png)
